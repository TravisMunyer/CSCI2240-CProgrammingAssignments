#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <libgen.h>

char * strdup(const char*);
int strcasecmp(const char *, const char*);

typedef struct word_data
{
  char *word;
  int count;
}word_data;

typedef struct arguments
{
  char *file_data;
  char *file_name;
  char *words_file_name;
  word_data **wordlist;
  int line_length;
  int num_words;
}args;

args get_args(char argc, char ** argv)
{
  args arg;
  int file_length;
  FILE * file_pointer = fopen(argv[2], "r");
  char * temp_file_data;
  arg.line_length = atoi(argv[1]);

  if(argc != 3)
  {
    printf("Invalid number of arguments.\n");
    exit(0);
  }
  if(!(arg.line_length >= 25 && arg.line_length <= 100))
  {
    printf("Invalid line length argument passed, must be a valid integer greater than 24 and less than 101.\n");
    exit(0);
  }
  if(file_pointer == NULL)
  {
    printf("Invalid file name argument.\n");
    exit(0);
  }
  else
  {
    fseek(file_pointer, 0, SEEK_END);
    file_length = ftell(file_pointer);
    fseek(file_pointer, 0, SEEK_SET);
    temp_file_data = (char *) malloc((file_length + 2)*sizeof(char));
    fread(temp_file_data, sizeof(char), file_length, file_pointer);
    arg.file_data = temp_file_data;
    strcat(arg.file_data, "\0");
    fclose(file_pointer);
    arg.file_name = strdup(basename(argv[2]));
    arg.words_file_name = strdup(basename(argv[2]));
    strcat(arg.words_file_name, ".words");
    strcat(arg.file_name, ".out");
  }

  return arg; 
}

void strip_chars(char * str, char * rem_char, char * new_char)
{
  char * char_occurrence;

  while((char_occurrence = strstr(str, rem_char)) != NULL)
  {
    *char_occurrence = *new_char;
  }
}

void add_string(char * str_to_add, char * delimiter, int line_length, FILE * file)
{
  int add_length = strlen(str_to_add);
  static int first_call = 0;
  static int total_length = 0;
  total_length = total_length + add_length;

  if (total_length < line_length)
  {
    if (first_call)
    {
      total_length++;
      fprintf(file, "%s", delimiter); 
    }
    first_call = 1;
  }
  else
  {
    fprintf(file, "\n");
    total_length = add_length;
  }
  
  fprintf(file, "%s", str_to_add);
}

void add_to_wordlist(char * word, args * data)
{
  int i, match = 0;
  if(data->wordlist == NULL)
  {
    data->wordlist = malloc(sizeof(word_data));
    data->num_words = 0;
  } 

  for (i = 0; i < data->num_words; i++)
  {
    if(strcmp(data->wordlist[i]->word, word) == 0)
    {
      data->wordlist[i]->count++;
      match = 1;
      break;
    }
  }

  if(!match)
  {
    data->wordlist = realloc(data->wordlist, (data->num_words + 1) * sizeof(word_data));
    data->wordlist[data->num_words] = malloc(sizeof(word_data));
    data->wordlist[data->num_words]->word = malloc(strlen(word + 1));
    data->wordlist[data->num_words]->word = strdup(word);
    data->wordlist[data->num_words]->count = 1;
    data->num_words++;
  }
}

int shift_compare(const void * lhs, const void * rhs)
{
  word_data *a = *(word_data **)lhs;
  word_data *b = *(word_data **)rhs;

  int result = strcasecmp(a->word, b->word);

  if (result != 0)
  {
    return result;
  }

  return strcmp(a->word, b->word);
}

void sort_wordlist(args * data)
{
  qsort(data->wordlist, data->num_words, sizeof(sizeof(data->wordlist[0])), shift_compare);
}

void print_wordlist(args * data)
{
  int i;
  FILE * file;
  file = fopen(data->words_file_name, "w");

  for(i = 0; i < data->num_words; i++)
  {
    fprintf(file,"%s - %d\n", data->wordlist[i]->word, data->wordlist[i]->count);
  }

  printf("Words output file location: %s\n", data->words_file_name);
}

void format_input(args * data)
{
  char * token;
  const char seperator[2] = " "; 
  FILE * output = fopen(data->file_name, "w");
  strip_chars(data->file_data, "\n", " ");
  strip_chars(data->file_data, "\t", " ");
  token = strtok(data->file_data, seperator);

  if (output != NULL)
  {
    while (token != NULL)
    {
      add_string(token, " ", data->line_length, output);
      add_to_wordlist(token, data);
      token = strtok(NULL, seperator);
    }
  }
  else
  {
    printf("Error when creating file at %s", data->file_name);
    exit(0);
  }

  printf("Formatted text output file location: %s\n", data->file_name);
}

int main(int argc, char **argv)
{
  args arg = get_args(argc, argv);
  format_input(&arg);
  sort_wordlist(&arg);
  print_wordlist(&arg);
  return 0;
}
