gcc -Wall -ansi -pedantic WordFormat.c -o format
