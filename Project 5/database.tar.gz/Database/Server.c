#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include "util.h" 
#define FILENAME "data.bin"
#define DELIMITER ","
#define BUFFER_SIZE 256
#define SID_ORDER 2

int strcasecmp(const char *, const char *);

void linked_insert(linked_student **node_ptr, SREC * new_student)
{
  linked_student * new_record;
  linked_student * current;
  linked_student * previous;
  
  new_record = (linked_student*) malloc(sizeof(linked_student));
  new_record->data = (SREC *) malloc(sizeof(SREC));

  if (new_record != NULL)
  {
    *new_record->data = *new_student;
    new_record->next = NULL;

    previous = NULL;
    current = *node_ptr;

    while(current != NULL && new_student->SID > current->data->SID)
    {
      previous = current;
      current = current->next;
    }

    if(previous == NULL)
    {
      new_record->next = *node_ptr;
      *node_ptr = new_record;
    }
    else
    {
      previous->next = new_record;
      new_record->next = current;
    }
  }
  else
  {
    printf("An error occurred when inserting the record.");
  }
}

SREC * copy_student(SREC * student)
{
  SREC * new_student = (SREC *)malloc(sizeof(SREC));

  if (student == NULL)
    return NULL;

  return memcpy(new_student, student, sizeof(SREC));
}

linked_student * copy_linked_list(linked_student ** current_list)
{
  linked_student * current;
  linked_student * new_list = NULL;
  linked_student * temp = NULL;

  if(*current_list == NULL)
  {
    return NULL;
  }

  current = *current_list;

  while(current != NULL)
  {
    if (new_list == NULL)
    {
      new_list = (linked_student *)malloc(sizeof(linked_student));
      new_list->data = copy_student(current->data);
      new_list->next = NULL;
      temp = new_list;
    }
    else
    {
      temp->next = (linked_student *)malloc(sizeof(linked_student));
      temp = temp->next;
      temp->data = copy_student(current->data);
      temp->next = NULL;
    }
    
    current = current->next;
  }

  return new_list;
}

int comparison(linked_student * node, int mode)
{
  int str_comparison;
  if (mode == 0)
  {
    str_comparison = strcasecmp(node->data->lname, node->next->data->lname);

    if (str_comparison == 0 || str_comparison < 0)
      return 0;
    else
      return 1;
  }
  else if (mode == 1)
  {
    str_comparison = strcasecmp(node->data->fname, node->next->data->fname);

    if (str_comparison == 0 || str_comparison < 0)
      return 0;
    else
      return 1;
  }
  else
  {
    return node->data->GPA < node->next->data->GPA;
  }
}

linked_student * order_linked(linked_student ** current_list, int type)
{
  linked_student * copy = copy_linked_list(current_list);
  linked_student * temp;
  linked_student * current;
  linked_student * previous;

  if (copy == NULL)
  {
    return NULL;
  }

  current = copy;
  previous = copy;

  while(current != NULL)
  {
    if (current->next == NULL)
    {
      break;
    }

    if (comparison(current, type))
    { 
      temp = current;
      if (current == copy)
      {
        temp = current->next;
        current->next = current->next->next;
        temp->next = current;
        copy = temp;
        current = copy;
        continue;
      }
      else
      {
        previous->next = current->next;
        temp = current->next;
        current->next = current->next->next;
        temp->next = current;
        current = copy;
        previous = current;
        continue;
      }
    }
    previous = current;
    current = current->next;
  }
  return copy;
}

void initialize_data(linked_student ** linked_students, char * file_name)
{
  FILE * file = fopen(file_name, "a+b");
  SREC student;

  if (file != NULL)
  {
    while(fread(&student, sizeof(student), 1, file))
    {
      linked_insert(linked_students, &student);
    }
  }
  fclose(file);
}

int get_student_count(linked_student ** students)
{
  linked_student * current;
  int count = 0;

  if(*students == NULL)
  {
    return 0;
  }

  current = *students;

  while(current != NULL)
  {
    count++;
    current = current->next;
  }
  return count;
}

int delete(linked_student ** students, int SID)
{
  linked_student * current;
  linked_student * previous;
  linked_student * temp;

  if(*students == NULL)
  {
    return -1;
  }
  
  if(SID == (*students)->data->SID)
  {
    temp = *students;
    *students = (*students)->next;
    free(temp);
    return SID;
  }
  else
  {
    previous = *students;
    current = (*students)->next;

    while(current != NULL && current->data->SID != SID)
    {
      previous = current;
      current = current->next;
    }

    if(current != NULL)
    {
      previous->next = current->next;
      free(current);
      return SID;
    }
  }
  return -1; 
}

linked_student * get(linked_student ** current_list, int order)
{
  if (order == 0 || order == 1 || order == 3)
  {
    return order_linked(current_list, order);
  }
  else if(order == SID_ORDER)
  {
    /* The list is stored in SID order, just return it. */
    return *current_list;
  }
  else
  {
    return NULL;
  }
}

void save(linked_student ** students, char * filename)
{
  linked_student * current;
  FILE * file = fopen(filename, "wb");

  if (*students == NULL)
  {
    fclose(file);
    return;
  }

  if (file == NULL)
  {
    return;
  }

  current = *students;

  while(current != NULL)
  {
    fwrite(current->data, sizeof(SREC), 1, file);
    current = current->next;
  }
  fclose(file);
}

void send_students(int sockfd, char * buffer, int size, linked_student ** students)
{
  linked_student * current;
  write_length(sockfd, get_student_count(students));

  if(*students == NULL)
  {
    return;
  }

  current = *students;

  while(current != NULL)
  {
    send_student(sockfd, buffer, size, *current->data);
    current = current->next;
  }
}

void free_linked(linked_student ** linked)
{
  linked_student * current = *linked;
  linked_student * temp = NULL;

  if (current != NULL)
  {
    temp = current->next;
    free(current->data);
    free(current);
    free_linked(&temp);
  }
}

int main()
{
  linked_student * students = NULL;
  int sockfd, newsockfd;
  socklen_t clilen;
  char buffer[BUFFER_SIZE];
  struct sockaddr_in serv_addr, cli_addr;
  CMD * command = (CMD *)malloc(sizeof(CMD));

  initialize_data(&students, FILENAME);
  sockfd = socket(AF_INET, SOCK_STREAM, 0);

  if (sockfd < 0)
    error("Error opening socket");

  memset((char *) &serv_addr, 0, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = INADDR_ANY;
  serv_addr.sin_port = htons(PORTNO);

  if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
    error("Error binding socket");

  if (listen(sockfd, 5) < 0)
    error("Error listening on socket");

  clilen = sizeof(cli_addr);
  newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
  if (newsockfd < 0)
    error("Error accepting connection");

  memset(buffer, 0, BUFFER_SIZE);

  for (;;)
  {
    if (recv(newsockfd, buffer, BUFFER_SIZE, MSG_PEEK) == 0)
    {
      newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
    }
    command->com_number = atoi(recieve_command_portion(newsockfd, buffer, BUFFER_SIZE));
    command->delete_data = atoi(recieve_command_portion(newsockfd, buffer, BUFFER_SIZE));
    strcpy(command->put_student.lname, recieve_command_portion(newsockfd, buffer, BUFFER_SIZE));
    command->put_student.initial = recieve_command_portion(newsockfd, buffer, BUFFER_SIZE)[0];
    strcpy(command->put_student.fname, recieve_command_portion(newsockfd, buffer, BUFFER_SIZE));
    command->put_student.SID = strtoul(recieve_command_portion(newsockfd, buffer, BUFFER_SIZE), NULL, 10);
    command->put_student.GPA = atof(recieve_command_portion(newsockfd, buffer, BUFFER_SIZE));

    if (command->com_number >= 0 && command->com_number <= 3)
    {
      linked_student * students_to_send = NULL;
      students_to_send = get(&students, command->com_number);
      send_students(newsockfd, buffer, BUFFER_SIZE, &students_to_send);
      
      if (command->com_number != SID_ORDER)
      {
        free_linked(&students_to_send);
      }
    }
    else if (command->com_number == 4)
      linked_insert(&students, &command->put_student);
    else if (command->com_number == 5)
      delete(&students, command->delete_data);
    else if (command->com_number == 6)
      save(&students, FILENAME);
    else
      error("Inputted command does not exist");
  }
  return 0;
}
