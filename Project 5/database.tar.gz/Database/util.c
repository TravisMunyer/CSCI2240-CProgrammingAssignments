#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "util.h"

float strtof(const char *, char **);
char * strdup(const char *);

size_t read_length(int fd)
{
    size_t buffer;

    readn(fd, &buffer, sizeof(buffer));
    return ntohl(buffer);
}

void write_length(int fd, size_t length)
{
    size_t buffer;

    buffer = htonl(length);
    writen(fd, &buffer, sizeof(buffer));
}

void readn(int fd, void *buffer, size_t count)
{
    int read_count = 0;

    while (read_count < count)
    {
        int retval = read(fd, (char *)buffer + read_count, count - read_count);
        
        if (retval == 0)
            error("Peer closed connection");
        else if (retval < 0)
            error("Socket error");
        else
            read_count += retval;
    }
}

void writen(int fd, void *buffer, size_t count)
{
    int written_count = 0;

    while (written_count < count)
    {
        int retval = write(fd, (char *)buffer + written_count, count - written_count);
        
        if (retval < 0)
            error("Socket error");
        else
            written_count += retval;
    }
}

void error(char *msg)
{
	perror(msg);
	exit(1);
}

SREC * create_student(char * data_line, char * delimiter)
{
  SREC * student = (SREC*)malloc(sizeof(SREC));
  int token_count = 0;
  char * token;

  if (student != NULL)
  {
    token = strtok(data_line, delimiter);

    while (token != NULL)
    {
      if (token_count == 0)
      {
        strncpy(student->lname, token, sizeof(student->lname)-1);
      }
      else if (token_count == 1)
      {
        strncpy(student->fname, token, sizeof(student->fname)-1);
      }
      else if (token_count == 2)
      {
        student->initial = token[0];
      }
      else if (token_count == 3)
      {
        int length;
        student->SID = strtoul(token, NULL, 10);
        length = strlen(token);

        if (length > 5)
        {
          printf("SID must be 5 or less digits, input SID %s is %d digits.\n", token, length);
          return NULL;
        }
      }
      else if (token_count == 4)
      {
        student->GPA = strtof(token, NULL);
        if (student->GPA > 10)
        {
          printf("GPA must be less than 10\n");
          return NULL;
        }
      }
      else
      {
        printf("Too many fields in input data_record\n");
        return NULL;
      }

      token = strtok(NULL, delimiter);
      token_count++;
    }

    if (token_count == 5)
    {
      return student;
    }
    else
    {
      printf("The following record is not in the proper format for conversion: %s\n", data_line);
      return NULL;
    }
  }
  return NULL;
}

void write_string(int sockfd, char * buffer)
{
  int length = strlen(buffer);
  write_length(sockfd, length);
  writen(sockfd, buffer, length);
}

char * recieve_command_portion(int sockfd, char * buffer, int size)
{
  int length = read_length(sockfd);
  
  if (length >= size)
    error("Message exceeds the buffer size");

  readn(sockfd, buffer, length);
  buffer[length] = '\0';
  return strdup(buffer);
}

void send_student(int sockfd, char * buffer, int size, SREC student)
{
  write_string(sockfd, student.lname);

  sprintf(buffer, "%c", student.initial);
  write_string(sockfd, buffer);
  memset(buffer, 0, size);

  write_string(sockfd, student.fname);

  sprintf(buffer, "%lu", student.SID);
  write_string(sockfd, buffer);
  memset(buffer, 0, size);

  sprintf(buffer, "%f", student.GPA);
  write_string(sockfd, buffer);
  memset(buffer, 0, size);
}
 
