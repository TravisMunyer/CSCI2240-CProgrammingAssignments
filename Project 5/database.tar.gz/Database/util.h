#if !defined(_UTIL_H_)
#define _UTIL_H_
#define PORTNO 25464

typedef struct student
{
  char initial;
  char lname[10];
  char fname[10];
  unsigned long SID;
  float GPA;
}SREC;

typedef struct command
{
  SREC put_student;
  int delete_data;
  int com_number;
}CMD;

typedef struct node
{
  SREC * data;
  struct node *next;
}linked_student;

size_t read_length(int fd);

void write_length(int fd, size_t length);

void readn(int fd, void * buffer, size_t count);

void writen(int fd, void * buffer, size_t count);

void error(char *msg);

SREC * create_student(char *, char *);

void write_string(int, char *);

void send_student(int, char *, int, SREC); 

char * recieve_command_portion(int, char *, int);

#endif /* _UTIL_H_ */
