#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include "util.h"
#define HOSTNAME "odin"
#define BUFFER_SIZE 256
#define SAVE_NUM 6

int strcasecmp(const char *, const char *);

CMD * convert(char * string)
{
  CMD * command = (CMD *) malloc(sizeof(CMD *));
  char * get_put_check = malloc(sizeof(char)*4);
  char * delete_check = malloc(sizeof(char)*7);
  int put, del;

  command->delete_data = -1;
  strncpy(delete_check, string, 6);
  strncpy(get_put_check, string, 3);
  delete_check[6] = '\0';
  get_put_check[3] = '\0';
  del = strcasecmp(delete_check, "delete");
  put = strcasecmp(get_put_check, "put");

  if (strcasecmp(get_put_check, "get") == 0)
  {
    if (strcasecmp(string, "get lname\n") == 0)
      command->com_number = 0;
    else if (strcasecmp(string, "get fname\n") == 0)
      command->com_number = 1;
    else if (strcasecmp(string, "get SID\n") == 0)
      command->com_number = 2;
    else if (strcasecmp(string, "get GPA\n") == 0)
      command->com_number = 3;
    else
      return NULL;
  }
  else if (put == 0 || del == 0)
  {
    char * split_string[2];
    char * c;
    
    split_string[0] = strtok(string, " ");
    split_string[1] = strtok(NULL, " ");

    if (split_string[1] == NULL)
    {
      return NULL;
    }
    
    c = &split_string[1][strlen(split_string[1])-1];

    if (*c == '\n')
      *c = '\0';

    if (put == 0)
    {
      SREC * student = create_student(split_string[1], ",");
      if (student == NULL )
        return NULL;

      command->put_student = *student;
      command->com_number = 4;
    }
    else
    {
      command->delete_data = atoi(split_string[1]);
      if (command->delete_data < 0)
      {
        printf("Delete input must be greater than 0");
        return NULL;
      }
      command->com_number = 5;
    }
  }
  else if (strcasecmp(string, "save\n") == 0)
  {
    command->com_number = SAVE_NUM;
  }
  else
  {
    return NULL;
  }

  return command;
}

void print_get_result(int sockfd, char * buffer, int size)
{
  int i;
  int record_count = read_length(sockfd);
  SREC student;

  printf("\n| SID   | Lname     | Fname     | M | GPA  |\n");
  printf("+-------+-----------+-----------+---+------+\n");


  for(i = 0; i < record_count; i++)
  {
     strcpy(student.lname, recieve_command_portion(sockfd, buffer, size));
     student.initial = recieve_command_portion(sockfd, buffer, size)[0];
     strcpy(student.fname, recieve_command_portion(sockfd, buffer, size));
     student.SID = strtoul(recieve_command_portion(sockfd, buffer, size), NULL, 10);
     student.GPA = atof(recieve_command_portion(sockfd, buffer, size));
     printf("| %0*lu | %-9s | %-9s | %c | %.2f |\n", 5, student.SID, student.lname, student.fname, student.initial, student.GPA);
  }

  printf("+-------+-----------+-----------+---+------+\n\n");
}

int main()
{
  int sockfd;
  struct sockaddr_in serv_addr;
  struct hostent *server;
  char buffer[BUFFER_SIZE];

  sockfd = socket(AF_INET, SOCK_STREAM, 0);

  if (sockfd < 0)
    error("ERROR opening socket");

  server = gethostbyname(HOSTNAME);

  if (server == NULL)
  {
    fprintf(stderr, "ERROR, no such host\n");
    exit(0);
  }

  memset((char *) &serv_addr, 0, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  memcpy((char *) server->h_addr_list, (char *) &serv_addr.sin_addr, server->h_length);
  serv_addr.sin_port = htons(PORTNO);

  if(connect(sockfd,  (struct sockaddr*) &serv_addr, sizeof(serv_addr)) < 0)
    error("ERROR connecting");

  for (;;)
  {
    CMD * command;

    printf("Please enter the command: ");

    fgets(buffer, sizeof(buffer)-1, stdin);

    command = convert(buffer);

    if (command == NULL)
    {
      printf("Invalid Command\n");
    }
    else
    {
      sprintf(buffer, "%d", command->com_number);
      write_string(sockfd, buffer);
      memset(buffer, 0, BUFFER_SIZE);

      sprintf(buffer, "%d", command->delete_data);
      write_string(sockfd, buffer);
      memset(buffer, 0, BUFFER_SIZE);

      send_student(sockfd, buffer, BUFFER_SIZE, command->put_student);

      if (command->com_number == SAVE_NUM)
      {
        printf("Saving and closing connection, goodbye!\n");
        exit(0);
      }
      else if (command->com_number >= 0 && command->com_number <=3)
      {
        print_get_result(sockfd, buffer, BUFFER_SIZE);
      }
    }
  }

  return 0;
}
