gcc -Wall -pedantic -ansi -lm VirtualMachine.c -o computer
