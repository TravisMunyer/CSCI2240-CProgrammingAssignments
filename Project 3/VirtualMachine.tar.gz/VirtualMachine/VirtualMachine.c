#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#define memory_size 100
#define assembly_language_length 15
#define command_set_number 22
#define command_halt_number 99

void halt(void *);

struct assembly
{
  char *command_string;
  int command_int;
  void (*func_ptr)(void *);
};

typedef struct
{
  int memory[memory_size];
  const int mem_size;
  const int assembly_size;
  int accumulator;
  int instruction_register;
  int set_command_number;
  int operation_code;
  int operand;
  int instruction_counter;
  int has_halt;
  int halt_int;
  struct assembly assembly_language[assembly_language_length];
}virtual_machine;

void print_memory(virtual_machine * vm)
{
  int i; 
  printf("REGISTERS:\naccumulator\t\t %+.4d\ninstructionCounter\t    %.2d\ninstructionRegister\t %+.4d\noperationCode\t\t    %.2d\noperand\t\t\t    %.2d\n",
         vm->accumulator, vm->instruction_counter, vm->instruction_register, vm->operation_code, vm->operand);
  printf("MEMORY:\n");
  printf("%8s%6s%6s%6s%6s%6s%6s%6s%6s%6s", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9");
  for (i = 0; i < vm->mem_size; i++)
  {
    if (i % 10 == 0)
    {
      printf("\n%2d ", i);
    }
    printf("%+.4d ", vm->memory[i]);
  }
  printf("\n");
}

int count_int_digits(int num)
{
  int count = (num == 0) ? 1 : (log10(abs(num)) + 1);
  return count;
}

int concat_int_and_string(int int1, char * str)
{
  int size = count_int_digits(int1) + sizeof(str);
  char * output_str = (char *) malloc(size);
  int output_int, num;
  num = atoi(str);
  sprintf(output_str, "%.2d%.2d", int1, num);
  output_int = atoi(output_str);
  return output_int;
}

struct assembly get_command(char * command_text, int command_number, virtual_machine * vm, int mem_location)
{
  int i;
  struct assembly empty = {0};
  for (i = 0; i < vm->assembly_size; i++)
  {
    if (command_number != -1)
    {
      if (command_number == vm->assembly_language[i].command_int)
      {
        if (vm->assembly_language[i].command_int == vm->halt_int)
        {
          vm->has_halt = 1;
        }
        return vm->assembly_language[i];
      }
    }
    if (command_text != NULL)
    {
      if (strcmp(command_text, vm->assembly_language[i].command_string) == 0)
      {
        if (vm->assembly_language[i].command_int == vm->halt_int)
        {
          vm->has_halt = 1;
        }
        return vm->assembly_language[i];
      }
    }
  }
  printf("Unknown Command at memory location %d.\n", mem_location);
  if (command_text == NULL)
  {
    halt(vm);
  }
  else
  {
    exit(0);
  }
  return empty;
}

void convert_line(char *line, virtual_machine * vm)
{
  char *initial_line = malloc(sizeof(line));
  char *seperated_line[3];
  char *token;
  char *endptr = NULL;
  struct assembly command;
  int mem_location, final_command, command_digits;
  int i = 0;

  strcpy(initial_line, line);
  token = strtok(initial_line, " ");

  /* Attempt to split input command into its parts. */
  while(token != NULL)
  {
    if (i > 2)
    {
      printf("Undefined Use: Too many arguments in line %s.\n", initial_line);
      exit(0);
    }
    seperated_line[i] = token;
    token = strtok(NULL, " ");
    i++;
  }

  /* Verify parses here */
  mem_location = strtol(seperated_line[0], &endptr, 10);
  if (mem_location > 100 || mem_location < 0)
  {
    printf("Segmentation Fault: Attempted addess %s on line %s.\n", seperated_line[0], line);
    exit(0);
  }

  command = get_command(seperated_line[1], -1, vm, mem_location);

  if (command.command_int == vm->set_command_number)
  {
    final_command = atoi(seperated_line[2]);
  }
  else
  {
    final_command = concat_int_and_string(command.command_int, seperated_line[2]);
  }

  command_digits = count_int_digits(final_command);

  if (command_digits > 4)
  {
    printf("Word overflow on line \"%s\"\n", line);
    exit(0);
  }
  vm->memory[mem_location] = final_command;
}

void add_char_to_line(char char_to_add, char * line_ptr, int line_size)
{
  size_t new_size = line_size + 1;
  line_ptr = (char *) realloc(line_ptr, new_size);
  line_ptr[line_size] = char_to_add;
}

void get_line(virtual_machine * vm)
{
  int line_size = 0;
  char next_char;
  char *line_ptr;
  line_ptr = (char *) malloc(1);

  do
  {
    next_char = fgetc(stdin);
    
    if (next_char == '\n' || next_char == EOF)
    {
      convert_line(line_ptr, vm);
      break;
    }
    else
    {
      add_char_to_line(next_char, line_ptr, line_size);
      line_size++;
    }
  }
  while(1);

  free(line_ptr);
}

void compile(virtual_machine * vm)
{
  char peek_char;
  while(1)
  {
    peek_char = fgetc(stdin);
    ungetc(peek_char, stdin);
    if (peek_char == EOF)
    {
      break;
    }
    get_line(vm);
  }
  if (!vm->has_halt)
  {
    printf("No halt command given.\n");
    exit(0);
  }
}

void halt(void *vm)
{
  print_memory(vm);
  exit(0);
}

void check_seg_fault(int index, virtual_machine * vm)
{
  if (index >= vm->mem_size || index < 0)
  {
    printf("ERROR: Segmentation Fault at memory location %d.\n", index);
    halt(vm);
  }
}

void check_accumulator_word_overflow(virtual_machine * vm)
{
  int count = count_int_digits(vm->accumulator);
  if (count > 4)
  {
    printf("Word Overflow in accumulator\n");
    halt(vm);
  }
}

void execute(virtual_machine * vm)
{
  struct assembly current_command;
    while(1)
  {
    if (vm->instruction_counter == vm->mem_size)
    {
      vm->instruction_counter = vm->mem_size-1;
      check_seg_fault(vm->mem_size, vm);
    }
    vm->operation_code = vm->memory[vm->instruction_counter] / 100;
    current_command = get_command(NULL, vm->operation_code, vm, vm->instruction_counter);
    vm->operand = vm->memory[vm->instruction_counter] % 100;
    vm->instruction_register = vm->memory[vm->instruction_counter];
    stdin = fopen("/dev/tty", "r");
    current_command.func_ptr(vm);
    vm->instruction_counter++;
  }
}

void read(void * vm)
{
  int input, count;
  scanf("%d", &input);
  count = count_int_digits(input);
  if (count > 0 && count <= 4)
  {
    ((virtual_machine*)vm)->memory[((virtual_machine*)vm)->operand] = input;
  }
  else
  {
    printf("Valid input consists of a total of 1-4 digits.\n");
    halt(vm);
  }
}

void writ(void * vm)
{
  printf("%d", ((virtual_machine*)vm)->memory[((virtual_machine*)vm)->operand]);
}

void prnt(void * vm)
{
  int i = ((virtual_machine*)vm)->operand;
  int size = 0, counter;
  char current_letter = ((virtual_machine*)vm)->memory[i] / 100;
  char * output = malloc(0);
  while (current_letter != 0)
  {
    for(counter = 0; counter < 2; counter++)
    {
      if (current_letter == 10 || (current_letter < 90 && current_letter > 65))
      {
        add_char_to_line(current_letter, output, size);
        size++;
      }
      else if (current_letter == 0)
      {
        break;
      }
      else
      {
        printf("Unknown character in memory location: %d\n", i);
        halt(vm);
      }
      current_letter = ((virtual_machine*)vm)->memory[i] % 100;
    }

    if (current_letter == 0)
    {
      break;
    }

    i++;
    check_seg_fault(i, vm);
    current_letter = ((virtual_machine*)vm)->memory[i] / 100;
  }
  printf("%s", output);
}

void load(void * vm)
{
  ((virtual_machine*)vm)->accumulator = ((virtual_machine*)vm)->memory[((virtual_machine*)vm)->operand];
}

void stor(void * vm)
{
  ((virtual_machine*)vm)->memory[((virtual_machine*)vm)->operand] = ((virtual_machine*)vm)->accumulator;
}

void add(void * vm)
{
  ((virtual_machine*)vm)->accumulator = ((virtual_machine*)vm)->accumulator + ((virtual_machine*)vm)->memory[((virtual_machine*)vm)->operand];
  check_accumulator_word_overflow((virtual_machine*)vm);
}

void sub(void * vm)
{
  ((virtual_machine*)vm)->accumulator = ((virtual_machine*)vm)->accumulator - ((virtual_machine*)vm)->memory[((virtual_machine*)vm)->operand];
  check_accumulator_word_overflow((virtual_machine*)vm);
}

void divd(void * vm)
{
  int divisor = ((virtual_machine*)vm)->memory[((virtual_machine*)vm)->operand];
  if (divisor == 0)
  {
    printf("Divide by zero error\n");
    halt(vm);
  }
  ((virtual_machine*)vm)->accumulator = ((virtual_machine*)vm)->accumulator / divisor;
  check_accumulator_word_overflow((virtual_machine*)vm);
}

void mult(void * vm)
{
  ((virtual_machine*)vm)->accumulator = ((virtual_machine*)vm)->accumulator * ((virtual_machine*)vm)->memory[((virtual_machine*)vm)->operand];
  check_accumulator_word_overflow((virtual_machine*)vm);
}

void mod(void * vm)
{
  int divisor = ((virtual_machine*)vm)->memory[((virtual_machine*)vm)->operand];
  if (divisor == 0)
  {
    printf("Divide by zero error\n");
    halt(vm);
  }
  ((virtual_machine*)vm)->accumulator = ((virtual_machine*)vm)->accumulator % divisor;
  check_accumulator_word_overflow((virtual_machine*)vm);
}

void go_to_memory_location(virtual_machine * vm)
{
  vm->instruction_counter = vm->operand - 1;
}

void bran(void * vm)
{
  go_to_memory_location((virtual_machine*)vm);
}

void brng(void * vm)
{
  if (((virtual_machine*)vm)->accumulator < 0)
  {
    go_to_memory_location((virtual_machine*)vm);
  }
}

void brzr(void * vm)
{
  if (((virtual_machine*)vm)->accumulator == 0)
  {
    go_to_memory_location((virtual_machine*)vm);
  }
}

int main()
{
  virtual_machine vm = { {0}, memory_size, assembly_language_length, 0, 0, command_set_number, 0, 0, 0, 0, command_halt_number, {{ "READ", 10, read}, {"WRIT", 11, writ}, {"PRNT", 12, prnt}, {"LOAD", 20, load},  {"STOR", 21, stor}, 
    {"SET", command_set_number}, {"ADD", 30, add}, {"SUB", 31, sub}, {"DIV", 32, divd}, {"MULT", 33, mult}, {"MOD", 34, mod}, {"BRAN", 40, bran}, {"BRNG", 41, brng}, {"BRZR", 42, brzr}, {"HALT", command_halt_number, halt}}};
  compile(&vm);
  execute(&vm);
  return 0;
}
