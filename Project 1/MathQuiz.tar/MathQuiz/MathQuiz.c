/* MathQuiz.c by Travis Munyer
 * 11 September 2020
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

/* This function generates a random number between 1 and the max number. */
int generate_number(int max_number)
{
  return (rand() % max_number) + 1;
}

/* This function randomly generates a negative or positive number including 0. */
int generate_possibly_negative_number(int max_number)
{
  int multiplyer = 1;
  int is_negative;
  max_number += 1;
  
  is_negative = rand() % 2;

  if (is_negative)
  {
    multiplyer = -1;
  }

  return (rand() % max_number) * multiplyer;
}

/* This function validates that a string is an integer. */
int validate_integer(char user_input[50])
{
  int converted_input;
  int input_length;
  char zero_string[50] = "0\n";

  input_length = strlen(user_input);

  /* Check to see if we have all the contents of the buffer. Clear the buffer if not. */
  if(!(feof(stdin) || (input_length != 0 && user_input[input_length-1] == '\n'))) 
  {
    printf("That input is too long.\n");

    /* Clear the all character left in the buffer. */
    while (getchar() != '\n');
    return 0;
  }

  /* We have a special case if the passed in string actually is 0, we don't want to print an error message if this is the case. */
  if (strcmp(user_input, zero_string) == 0)
  {
    return 1;
  }

  /* Try to convert the input into an integer, returns 0 if a failure occurs. */
  converted_input = atoi(user_input);

  /* Make sure input was an integer. */
  if (converted_input == 0)
  {
    printf("Input must be a valid integer.\n");
    return 0;
  }
  
  /* If all validations succeeded, return true. */
  return 1;
}

/* This function is responsible for printing the applicable response to the player. */
void print_response(int is_correct, int correct_answer)
{
  /* Generate response number. */
  int response_key = generate_number(3);

  switch (response_key)
  {
    case 1:
      if (is_correct)
      {
        printf("Nice work!");
      }
      else
      {
        printf("Too bad!");
        printf("\nThe correct answer was %d", correct_answer);
      }
      break;
    case 2:
      if (is_correct)
      {
        printf("Way to go!");
      }
      else
      {
        printf("Better luck next time!");
        printf("\nThe correct answer was %d", correct_answer);
      }
      break;
    case 3:
      if (is_correct)
      {
        printf("You are right!");
      }
      else
      {
        printf("Wrong!");
        printf("\nThe correct answer was %d", correct_answer);
      }
      break;
    default:
      printf("An error occurred when validating your answer.");
      return;
  }
}

/* This function generates a question for the user to answer. */
int generate_question(int difficulty, int current_question)
{
  /* Define variables. */
  const int DIFFICULTY_ONE_MAX = 10;
  const int DIFFICULTY_TWO_MAX = 50;
  const int DIFFICULTY_THREE_MAX = 100;
  const int DIFFICULTY_FOUR_MAX = 100;
  int question_first_number;
  int question_second_number;
  int max;
  int can_be_negative = 0;
  int operator_randomizer;
  char operator;
  int answer;

  /* Set the max number depending on the set difficulty. */
  if (difficulty  == 1)
  {
    max = DIFFICULTY_ONE_MAX;
  }
  else if (difficulty == 2)
  {
    max = DIFFICULTY_TWO_MAX;
  }
  else if (difficulty == 3)
  {
    max = DIFFICULTY_THREE_MAX;
  }
  else
  {
    /* Difficulty four can have negative numbers, so allow this. */
    can_be_negative = 1;
    max = DIFFICULTY_FOUR_MAX;
  }
  
  /* Decide whether or not to allow negative numbers. */
  if (can_be_negative)
  {
    question_first_number = generate_possibly_negative_number(max);
    question_second_number = generate_possibly_negative_number(max);
  }
  else
  {
    question_first_number = generate_number(max);
    question_second_number = generate_number(max);
  }

  /* Get the operator to be used for this question. */
  operator_randomizer = generate_number(4);
  if (operator_randomizer == 1)
  {
    operator = '+';
    answer = question_first_number + question_second_number;
  }
  else if (operator_randomizer == 2)
  {
    operator = '-';
    answer = question_first_number - question_second_number;
  }
  else if (operator_randomizer == 3)
  {
    operator = '*';
    answer = question_first_number * question_second_number;
  }
  else if (operator_randomizer == 4)
  {
    operator = '/';

    /* Since we are dividing, do not allow the second number to be zero. */
    while (question_second_number == 0)
    {
      /* Still need to account for allowing positive and negative numbers in certain situations. */
      if (can_be_negative)
      {
        question_second_number = generate_possibly_negative_number(max);
      }
      else
      {
        question_second_number = generate_number(max);
      }
    }

    answer = question_first_number / question_second_number;
  }

  /* Now that we have everything we need, print the question. */
  printf("\nQuestion #%d: %d %c %d =", current_question, question_first_number, operator, question_second_number);

  /* Finally, return the answer. */
  return answer;
}

/* This function is responsible for verifying an answer. */
int answer_question(int correct_answer)
{
  char user_response[50];
  int converted_input;

  printf("\nEnter Answer: ");
  fgets(user_response, 50, stdin);

  /* Make sure input was valid. If not, get another input. */
  if (!validate_integer(user_response))
  {
    return answer_question(correct_answer);
  }

  converted_input = atoi(user_response);

  return converted_input == correct_answer;
}

/* This function gets the user set difficulty. */
int get_difficulty()
{
  char user_difficulty[50];
  int converted_input;

  printf("Select difficulty (1-4): ");
  fgets(user_difficulty, 50, stdin);

  if (!validate_integer(user_difficulty))
  {
    return get_difficulty();
  }

  /* Convert the input to an integer. */
  converted_input = atoi(user_difficulty);

  /* Check to make sure the input fits required parameters. */
  if(converted_input > 4 || converted_input < 1)
  {
    printf("Difficulty must be between 1 and 4, try again.\n");
    return get_difficulty();
  }

  return converted_input;
}

/* This function gets the user set quiz length. */
int get_quiz_length()
{
  char user_length[50];
  int converted_input;

  printf("How many questions for this test (1-20)? ");
  fgets(user_length, 50, stdin);

  if(!validate_integer(user_length))
  {
    return get_quiz_length();
  }

  converted_input = atoi(user_length);
 
  /* Check to make sure the input fits required parameters. */
  if (converted_input > 20 || converted_input < 1)
  {
    printf("Quiz length must be between 1 and 20, try again.\n");
    return get_quiz_length();
  }

  return converted_input;
}

/* This function iterates the length of the quiz. */
void iterate_quiz_length( )
{
  int quiz_length = get_quiz_length();
  int quiz_difficulty = get_difficulty();
  int correct_answer;
  int number_correct = 0;
  int current_question;
  int is_correct;

  for (current_question = 1; current_question <= quiz_length; current_question++)
  {
    correct_answer = generate_question(quiz_difficulty, current_question);
    is_correct = answer_question(correct_answer);
    
    /* Increase the number correct counter if the answer is correct. */
    if (is_correct)
    {
      number_correct++;
    }

    print_response(is_correct, correct_answer);
  }

  printf("\nYour score was %d/%d\n\n", number_correct, quiz_length);
}

/* This function is the entrance into this program. */
int main()
{
  /* Seed the rand function for the entire program. */
  srand(time(NULL));

  /* Iterate the length of the quiz. */
  iterate_quiz_length();

  return 0;
}
