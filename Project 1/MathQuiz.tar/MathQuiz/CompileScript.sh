gcc -Wall -ansi -pedantic MathQuiz.c
