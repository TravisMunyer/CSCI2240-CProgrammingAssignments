gcc -Wall -ansi -pedantic WordSearch.c
