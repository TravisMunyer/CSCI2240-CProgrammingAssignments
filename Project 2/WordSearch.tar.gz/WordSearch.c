/* Programmer: Travis Munyer
 * Date: 23 September 2020
 */

#include <stdio.h>
#include <string.h>

#define max_puzzle_size 51
#define puzzle_spacing 3
#define correct_marker "-"
#define temp_marker "*"

int check_direction(char puzzle[][max_puzzle_size][puzzle_spacing], int, char, int*, int*, int, char);

/* This function reads the puzzle from the txt file and stores it in an array. Returns the dimensions of the array. */
int get_puzzle(char puzzle[][max_puzzle_size][3])
{
  int x_indexer = 0;
  int y_indexer = 0;
  int puzzle_dimension = max_puzzle_size;
  char puzzle_char;

  do
  {
    /* Get the next character in the input file. */
    puzzle_char = fgetc(stdin);

    /* Check to see if we have hit a new line. */
    if (puzzle_char == '\n')
    {
      if (y_indexer == 0)
      {
        puzzle_dimension = x_indexer;
      }
      y_indexer++;
      x_indexer = 0;

      /* We do not want to store the newline characters. */
      continue;
    }

    /* Add the current character to our 3d array. */
    strncat(puzzle[y_indexer][x_indexer], &puzzle_char, 1);

    /* Check to see if we have hit a new letter-space combination. */
    if(strlen(puzzle[y_indexer][x_indexer]) == 2)
    {
      x_indexer++; 
    }
  }
  while (y_indexer != puzzle_dimension);

  return puzzle_dimension;
}

/* This function cleans the array. If the complete_clean variable is true, the unused characters are removed as well. */ 
void clean_array(char puzzle[][max_puzzle_size][3], int size, int complete_clean)
{
  int i, j;
  for (i = 0; i < size; i++)
  {
    for (j = 0; j < size; j++)
    {
      if (puzzle[i][j][1] == *temp_marker)
      {
        puzzle[i][j][1] = *" ";
      }

      if (complete_clean)
      {
        if (puzzle[i][j][1] == *" ")
        {
          puzzle[i][j][0] = *" ";
        }

        if (puzzle[i][j][1] == *correct_marker)
        {
          puzzle[i][j][1] = *" ";
        }
      }
    }
  }
}

/* This function prints the passed in puzzle strings. */
void print_array(char array[max_puzzle_size][max_puzzle_size][3], int size)
{
  int i;
  int j;

  for (i = 0; i < size; i++)
  {
    for (j = 0; j < size; j++)
    {
        printf("%s", array[i][j]);
    }
    printf("\n");
  }
}

/* This function gets the word list and returns the number of words. */
int get_word_list(char word_list[][max_puzzle_size])
{
  char word_char;
  int indexer = 0;

  do
  {
    word_char = fgetc(stdin);

    /* Move to next line and do not collect the newline character. */
    if (word_char == '\n')
    {
      indexer++;
      continue;
    }

    strncat(word_list[indexer], &word_char, 1);
  }
  while (word_char != EOF);

  return indexer;
}

/* This function compares a char to another char and returns true or false. */
int compare_char(char char_one, char char_two)
{
  if (char_one == char_two)
    return 1;
  else
    return 0;
}

/* This function iterates through the puzzle array and locates the specified word. */
void search_for_word(char puzzle[][max_puzzle_size][puzzle_spacing], int size, char word[])
{
  /* Single letter variables are simply loop indexers. */
  int i, j, t, f, initializer_one, initializer_two, direction;
  int *temp_row = &initializer_one;
  int *temp_column = &initializer_two;
  int complete_word = 0;
  int is_correct_character = 1;
  char *puzzle_pointers[max_puzzle_size];

  for (i = 0; i < size; i++)
  {
    for (j = 0; j < size; j++)
    {
      if (compare_char(puzzle[i][j][0], word[0]))
      {
        /* Mark this letter. */
        if (puzzle[i][j][1] != *correct_marker)
        {
          puzzle[i][j][1] = *"*";
        }
        for (direction = 1; direction <= 8; direction++)
        {
          *temp_row = i;
          *temp_column = j;
          is_correct_character = 1;
          complete_word = 0;

          /* If checking a specific direction is successful, continute to check the same direction. */
          for (t = 1; is_correct_character; t++)
          {
            is_correct_character = check_direction(puzzle, size, word[t], temp_row, temp_column, direction, *temp_marker);
            if (!is_correct_character)
            {
              break;
            }

            puzzle_pointers[t] = puzzle[*temp_row][*temp_column]; 

            /* If we found the entire word, exit this loop. */
            if (t == (strlen(word)-1))
            {
              complete_word = 1;
              break;
            }
          }

          if (complete_word)
          {
            /* Clean incorrect markers out of the puzzle. */
            puzzle[i][j][1] = *correct_marker;
            for(f = 1; f <= t; f++)
            {
              puzzle_pointers[f][1] = *correct_marker;
            }
            clean_array(puzzle, size, 0);
            break;
          }
        }
      }
      if (complete_word)
      {
        break;
      }
    }
    if (complete_word)
    {
      break;
    }
  }
}

/* This function iterates through the wordlist. */
void iterate_wordlist(char puzzle[][max_puzzle_size][puzzle_spacing], int size, char word_list[][max_puzzle_size], int word_count)
{
  int i;

  for (i = 0; i < word_count; i++)
  {
    search_for_word(puzzle, size, word_list[i]);
  }
}

/* This function ensures the specified indexes are still within the puzzle array. */
int validate_borders(int target_row, int target_column, int size)
{
  if (target_row >= 0 && target_row < size && target_column >= 0 && target_column < size)
    return 1;
  return 0;
}

/* This function marks the character in the specified direction if it matches the search character. */
int check_new_direction(char puzzle[][max_puzzle_size][puzzle_spacing], int size, char search_character, int target_row, int target_column, char replacement_char)
{
  int is_valid = 0;
  if (validate_borders(target_row, target_column, size))
  {
    is_valid = compare_char(puzzle[target_row][target_column][0], search_character);
    if (is_valid)
    {
      if (puzzle[target_row][target_column][1] != *correct_marker)
      {
        puzzle[target_row][target_column][1] = replacement_char;
      }
    }
    return is_valid;
  }

  return 0;
}

/* This function searchs the puzzle in a specified direction. */
/* The direction parameter will modify the direction searched in. */
int check_direction(char puzzle[][max_puzzle_size][puzzle_spacing], int size, char search_character, int* current_row, int* current_column, int direction, char replacement_char)
{
  int target_row, target_column;

  switch (direction)
  {
    /* left */
    case 1:
      target_row = *current_row;
      target_column = *current_column - 1;
      break;

    /* right */
    case 2:
      target_row = *current_row;
      target_column = *current_column + 1;
      break;

    /* up */
    case 3:
      target_row = *current_row + 1;
      target_column = *current_column;
      break;

    /* down */ 
    case 4:
      target_row = *current_row - 1;
      target_column = *current_column;
      break;

    /* up-right */  
    case 5:
      target_row = *current_row + 1;
      target_column = *current_column + 1;
      break;

    /* down-right */
    case 6:
      target_row = *current_row - 1;
      target_column = *current_column + 1;
      break;

    /* up-left */
    case 7:
      target_row = *current_row + 1;
      target_column = *current_column - 1;
      break;

    /* down-left */
    case 8:
      target_row = *current_row - 1;
      target_column = *current_column - 1;
      break;

    default:
      printf("\nAn error occured when trying to navigate the puzzle in an invalid direction.\n");
      return 0;
  }
  
  if (validate_borders(target_row, target_column, size))
  {
    *current_row = target_row;
    *current_column = target_column;
  }

  return check_new_direction(puzzle, size, search_character, target_row, target_column, replacement_char);
}

/* The main entrance into the application. */
int main()
{
  char puzzle[max_puzzle_size][max_puzzle_size][puzzle_spacing];
  char word_list[max_puzzle_size][max_puzzle_size];
  int puzzle_dimension;
  int word_list_size;

  puzzle_dimension = get_puzzle(puzzle);
  word_list_size = get_word_list(word_list);
  iterate_wordlist(puzzle, puzzle_dimension, word_list, word_list_size);

  clean_array(puzzle, puzzle_dimension, 1);
  print_array(puzzle, puzzle_dimension);

  return 0;
}
